﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MemberEligibility.CustomModel
{
    public class TechnologyEntityModel
    {
        public int TechnologyID { get; set; }
        public string TechnologyName { get; set; }
    }
}