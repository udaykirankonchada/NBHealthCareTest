﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MemberEligibility.CustomModel
{
    public class MemberModelClass
    {
        public int MemberID { get; set; }
        public string MemberName { get; set; }
    }
}